"use client";
import { useState } from "react";
import Link from "next/link";
import styles from "./login.module.css";
export default function LoginForm() {
  const [recovery, setRecovery] = useState(false);
  const [visible, setVisible] = useState(false);
  const [message, setMessage] = useState("");
  return <div className={styles.card}>
    <form key={recovery ? "recovery" : "login"} className={styles.form} onSubmit={event => { event.preventDefault(); event.currentTarget.reset(); setVisible(false); setMessage(recovery ? "Password recovery preview only. No email has been sent." : "Log In preview only. No credentials were sent or saved, and no account has been signed in."); }} onChange={() => setMessage("")}>
      <p className={styles.eyebrow}>{recovery ? "LET’S GET YOU BACK IN." : "YOUR RIDER ACCOUNT"}</p><h2>{recovery ? "RESET YOUR PASSWORD" : "LOG IN TO YOUR GARAGE"}</h2>
      {recovery && <p className={styles.help}>Enter the email address associated with your account to request a password reset.</p>}
      <label htmlFor="rider-email">EMAIL ADDRESS</label><input id="rider-email" name="email" type="email" autoComplete="email" required maxLength={254} />
      {!recovery && <><label htmlFor="rider-password">PASSWORD</label><div className={styles.password}><input id="rider-password" name="password" type={visible ? "text" : "password"} autoComplete="current-password" required maxLength={256} /><button type="button" aria-controls="rider-password" aria-label={visible ? "Hide password" : "Show password"} aria-pressed={visible} onClick={() => setVisible(current => !current)}>{visible ? "HIDE" : "SHOW"}</button></div><button className={styles.forgot} type="button" onClick={() => { setRecovery(true); setVisible(false); setMessage(""); }}>FORGOT YOUR PASSWORD?</button></>}
      <button className={styles.button} type="submit">{recovery ? "SEND RESET LINK" : "LOG IN"}<span aria-hidden="true">→</span></button><p className={styles.status} role="status">{message}</p>
      {recovery ? <button className={styles.back} type="button" onClick={() => {setRecovery(false);setMessage("");}}>← BACK TO LOG IN</button> : <p className={styles.newHere}>Don’t have an account? <Link href="/sign-up">SIGN UP</Link></p>}
    </form>
  </div>;
}
