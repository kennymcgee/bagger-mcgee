import Link from "next/link";
import { PublicHeader, PublicFooter } from "../public-shell";
import shared from "../home.module.css";
import styles from "./login.module.css";
import LoginForm from "./login-form";
export default function LoginPage() {
  return <div className={shared.site}>
    <a className={shared.skip} href="#login-main">Skip to log in</a><PublicHeader />
    <main id="login-main" className={styles.main}>
      <div className={styles.hero}><p className={styles.eyebrow}>YOUR GARAGE IS CALLING.</p><h1>LOG IN.<br /><span>GET BACK TO YOUR RIDE.</span></h1><p>Your bikes. Your saved parts. Your next project.<br />Pick up where you left off.</p></div>
      <div className={styles.layout}>
        <section className={styles.welcome}><h2>WELCOME BACK.</h2><p>Keep your Harley-Davidson and Indian bikes together, choose the rides you’re shopping for, and get back to finding parts.</p><ul><li><span>01</span><div><h3>YOUR GARAGE</h3><p>All your bikes, ready for your next search.</p></div></li><li><span>02</span><div><h3>YOUR SAVED PARTS</h3><p>Return to the parts you’re considering.</p></div></li><li><span>03</span><div><h3>YOUR RIDER VOICE</h3><p>Share retailer experiences and star ratings for review.</p></div></li></ul><p className={styles.browse}>Just looking for parts? <Link href="/">KEEP BROWSING →</Link></p></section>
        <LoginForm />
      </div>
      <div className={styles.signup}><div><h2>FIRST TIME HERE?</h2><p>Create an account and give your bikes a place to call home.</p></div><Link href="/sign-up" className={styles.outline}>BUILD YOUR GARAGE →</Link></div>
    </main>
    <PublicFooter previewNote="For Sam and Kenny. Rider Log In design preview. Login and password recovery forms are demonstrations: no credentials are transmitted or saved, no login session is created, and no recovery email is sent. Secure rider authentication, password recovery, persistent Garages, saved parts, and account review services remain launch work. Owner authentication is separate and unchanged. Remove design disclosures before launch." />
  </div>;
}
