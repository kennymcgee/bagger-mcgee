"use client";
import { useState } from "react";
import styles from "./retailers.module.css";
export default function InterestForm({ selectedPlan }: { selectedPlan?: string }) {
  const [reviewed, setReviewed] = useState(false);
  return <form className={styles.form} onSubmit={event => { event.preventDefault(); setReviewed(true); }} onChange={() => setReviewed(false)}>
    {selectedPlan && <input type="hidden" name="plan" value={selectedPlan} />}
    <div className={styles.fields}>
      <label>STORE NAME<input name="store" autoComplete="organization" required maxLength={150} /></label>
      <label>WEBSITE<input name="website" type="url" placeholder="https://" required maxLength={500} /></label>
      <label>YOUR NAME<input name="contact" autoComplete="name" required maxLength={150} /></label>
      <label>BUSINESS EMAIL<input name="email" type="email" autoComplete="email" required maxLength={254} /></label>
    </div>
    <fieldset><legend>WHAT DO YOU CARRY?</legend><div className={styles.choices}><label><input type="checkbox" name="harley" /> Harley-Davidson</label><label><input type="checkbox" name="indian" /> Indian</label></div></fieldset>
    <label>ANYTHING ELSE? <span className={styles.optional}>(OPTIONAL)</span><textarea name="notes" rows={3} maxLength={2000} placeholder="Parts you specialize in, catalog size, or questions for us." /></label>
    <button className={styles.button} type="submit">LET’S TALK PARTS <span aria-hidden="true">→</span></button>
    <p role="status" className={styles.status}>{reviewed ? "Demo reviewed. Nothing has been sent or saved; retailer inquiries are not connected yet." : ""}</p>
  </form>;
}
