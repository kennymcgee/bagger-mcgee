import Link from "next/link";
import { PublicHeader, PublicFooter } from "../public-shell";
import shared from "../home.module.css";
import styles from "./retailers.module.css";
import InterestForm from "./interest-form";

export default function Retailers() {
  return <div className={shared.site}>
    <a className={shared.skip} href="#retailer-main">Skip to retailer information</a>
    <PublicHeader />
    <main id="retailer-main" className={styles.main}>
      <div className={styles.hero}>
        <p className={styles.eyebrow}>YOUR PARTS. THEIR NEXT RIDE.</p>
        <h1>GET LISTED</h1>
        <p className={styles.headline}>You bring the parts.<br /><span>We help riders find them.</span></p>
        <p className={styles.intro}>Put your catalog in the path of Harley-Davidson and Indian riders looking for their next part. They compare on Bagger McGee. They buy from you.</p>
        <a className={styles.button} href="#retailer-interest">LET’S TALK PARTS <span aria-hidden="true">→</span></a>
      </div>
      <section className={styles.benefits} aria-label="Why list with Bagger McGee">
        <article><span className={styles.benefitLabel}>DISCOVERY</span><h2>GET FOUND.</h2><p>Help riders find your offers by bike, part, and the details that matter.</p></article>
        <article><span className={styles.benefitLabel}>COMPARISON</span><h2>SHOW THE FULL OFFER.</h2><p>Bring price, condition, shipping information, and available coupons into the comparison.</p></article>
        <article><span className={styles.benefitLabel}>YOUR STORE</span><h2>KEEP THE CUSTOMER.</h2><p>Your checkout. Your fulfillment. Your customer relationship. The sale happens with you.</p></article>
      </section>
      <section className={styles.section} aria-labelledby="process-title">
        <h2 id="process-title">FROM YOUR CATALOG TO THEIR SHORTLIST.</h2>
        <ol className={styles.steps} aria-label="Retailer listing timeline">
          <li><span>01</span><div><h3>INTRODUCE YOUR STORE.</h3><p>Tell us who you are, what you carry, and where riders can find you.</p></div></li>
          <li><span>02</span><div><h3>WORK THROUGH THE DETAILS.</h3><p>We discuss participation, permission to use your product data, and how your catalog can be supplied and kept current.</p></div></li>
          <li><span>03</span><div><h3>REVIEW BEFORE GOING LIVE.</h3><p>Product details are reviewed before publication. Once participation and listings are approved, riders can discover your offers and visit your store.</p></div></li>
        </ol>
        <aside className={styles.liveHelp} aria-labelledby="live-help-title"><h3 id="live-help-title">REAL PEOPLE. READY TO TALK.</h3><p>At any point during onboarding, you can call and speak with a live agent—a real person, not AI. Whether you have a quick question or need help with your catalog, we’re here to walk you through it.</p></aside>
      </section>
      <section className={`${styles.section} ${styles.catalog}`} aria-labelledby="catalog-title">
        <div><h2 id="catalog-title">GOOD DATA.<br />BETTER COMPARISONS.</h2><p className={styles.sectionIntro}>Start with an introduction. We’ll work through the catalog details together.</p><Link className={styles.textLink} href="/shipping-score">HOW SHIPPING SCORES WORK ↗</Link></div>
        <ul className={styles.checklist}>
          <li><strong>The exact part</strong><span>Brand, manufacturer part number, and variant.</span></li>
          <li><strong>The right bike</strong><span>Fitment information supported by your product data.</span></li>
          <li><strong>The current offer</strong><span>Price, condition, availability, and product link.</span></li>
          <li><strong>The shipping details</strong><span>Charges, free-shipping thresholds, and conditions.</span></li>
        </ul>
      </section>
      <section id="retailer-interest" className={`${styles.section} ${styles.interest}`} aria-labelledby="interest-title">
        <div><p className={styles.eyebrow}>LET’S GET ACQUAINTED.</p><h2 id="interest-title">TELL US ABOUT<br />YOUR STORE.</h2><p className={styles.sectionIntro}>Carry parts for Harley-Davidson or Indian motorcycles? Let’s start a conversation.</p><p className={styles.aside}>An introduction starts the review process. Participation and product listings require approval.</p></div>
        <InterestForm />
      </section>
    </main>
    <PublicFooter previewNote="For Sam and Kenny. Get Listed design concept. The interest form is a demonstration: nothing is sent or saved. Retailer participation, commercial terms, catalog connections, and live services are not established. Remove design disclosures before launch." />
  </div>;
}
