import Link from "next/link";
import { notFound } from "next/navigation";
import { findDemoOffer } from "../../demo-catalog";
import { PublicHeader, PublicFooter } from "../../public-shell";
import FlagForm from "../../flag-form";
import styles from "../../home.module.css";
export default async function FlagPage({params}:{params:Promise<{id:string}>}){const {id}=await params;const offer=findDemoOffer(id);if(!offer)notFound();return <div className={styles.site}><PublicHeader/><main className={styles.info}><Link href={`/share/${encodeURIComponent(id)}`}>← Back to this listing</Link><h1>Help keep the details right.</h1><p>Flag a problem with this demo listing.</p><div className={styles.sharedCard}><h2>{offer.name}</h2><p>{offer.retailer} · {offer.code} · ${offer.price.toFixed(2)}<br/>Fictional offer; retailer participation is not implied.</p></div><FlagForm id={id}/></main><PublicFooter/></div>;}
