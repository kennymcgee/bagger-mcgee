"use client";
import Link from "next/link";
import { useState } from "react";
import InterestForm from "../for-retailers/interest-form";
import styles from "./pricing.module.css";

const tiers = [
  { name: "RETAILER TIER 1", price: 69, range: "1–100 active listed SKUs" },
  { name: "RETAILER TIER 2", price: 89, range: "101–500 active listed SKUs" },
  { name: "RETAILER TIER 3", price: 129, range: "501–1,000 active listed SKUs" },
];
export default function PlanSelection() {
  const [selected, setSelected] = useState("");
  const [mixed, setMixed] = useState(false);
  const [band, setBand] = useState("0");
  const custom = mixed && band === "custom";
  const mfrPrice = mixed && !custom ? (49 + tiers[Number(band)].price) / 2 : 49;
  const mfrLabel = custom ? "Manufacturer Direct — mixed catalog over 1,000 SKUs; catalog review" : `Manufacturer Direct — ${mixed ? `mixed catalog, ${tiers[Number(band)].range}` : "own-brand catalog"} — $${mfrPrice}/month after 60 days free`;
  return <>
    <section className={styles.cards} aria-label="Choose a listing plan">
      <article className={`${styles.card} ${styles.mfr}`}>
        <p className={styles.eyebrow}>FOR VERIFIED MANUFACTURERS</p><h2>MANUFACTURER<br />DIRECT</h2>
        <p className={styles.price}><strong>$49</strong><span>/ month</span></p>
        <p className={styles.allowance}>Your own-brand parts catalog</p>
        <p>For businesses that manufacture the brand they list.</p>
        <p className={styles.badge}>VERIFIED MFR DIRECT</p>
        <p className={styles.small}>Badge applies to your own-brand listings only.</p>
        <a href="#start-onboarding" className={styles.button} onClick={() => setSelected("Manufacturer Direct — own-brand catalog — $49/month after 60 days free")}>CHOOSE MFR DIRECT <span aria-hidden="true">→</span></a>
      </article>
      {tiers.map(tier => <article className={styles.card} key={tier.name}>
        <p className={styles.eyebrow}>FOR MULTI-BRAND RETAILERS</p><h2>{tier.name}</h2>
        <p className={styles.price}><strong>${tier.price}</strong><span>/ month</span></p>
        <p className={styles.allowance}>{tier.range}</p>
        <p>List your complete Harley-Davidson and Indian parts catalog on Bagger McGee. All eligible parts must be included.</p>
        <a href="#start-onboarding" className={styles.button} onClick={() => setSelected(`${tier.name} — ${tier.range} — $${tier.price}/month after 60 days free`)}>CHOOSE TIER {tiers.indexOf(tier) + 1} <span aria-hidden="true">→</span></a>
      </article>)}
    </section>
    <section className={styles.overage}><div><h2>MORE THAN 1,000 SKUs?</h2><p>Let’s review your complete Harley-Davidson and Indian parts catalog and discuss pricing for all eligible SKUs.</p></div><a href="#start-onboarding" className={styles.outline} onClick={() => setSelected("Retailer catalog review — more than 1,000 active listed SKUs; price to be discussed")}>TALK TO US <span aria-hidden="true">→</span></a></section>
    <section className={styles.section}>
      <h2>THE SAME FAIR SHOT. EVERY PLAN.</h2>
      <div className={styles.features}><div><h3>YOUR STORE MAKES THE SALE.</h3><p>Riders compare here, then visit your product page to buy from you.</p></div><div><h3>RANKINGS STAY INDEPENDENT.</h3><p>Your plan, payment, and MFR badge never influence ranking or Shipping Score.</p></div><div><h3>REAL PEOPLE. READY TO TALK.</h3><p>Call at any point during onboarding and speak with a live agent—a real person, not AI.</p></div></div>
    </section>
    <section className={`${styles.section} ${styles.details}`}>
      <div><h2>WHAT COUNTS AS A SKU?</h2><p>A SKU identifies a specific item or variant in your catalog. Your plan covers all eligible Harley-Davidson and Indian parts in your catalog. Full-catalog participation is required; selecting only certain parts is not an option.</p><p>A black part and a chrome version with different SKUs count separately. One SKU that fits several motorcycle models counts once. Stock quantity does not multiply your count.</p></div>
      <div><h2>WHO QUALIFIES FOR MFR?</h2><p>Your website must clearly state that you manufacture your brand. Kenny personally reviews and verifies your eligibility.</p><p>Exclusive importers, territory holders, and master distributors use retailer tiers unless they also meet the manufacturing requirement.</p></div>
    </section>
    <section className={`${styles.section} ${styles.mixed}`}>
      <div><h2>MANUFACTURE YOUR BRAND.<br />CARRY OTHER BRANDS, TOO?</h2><p>A verified manufacturer lists its complete eligible Harley-Davidson and Indian parts catalog under one MFR account. If you carry other brands, they must be included too. For a mixed catalog, count all active listed SKUs. Your monthly price is the average of $49 and the applicable retailer-tier price.</p><p>One account. One charge. Always below the standard retailer price for these tiers. Your MFR badge stays on your own-brand listings.</p></div>
      <div className={styles.calculator}>
        <label className={styles.checkbox}><input type="checkbox" checked={mixed} onChange={event => setMixed(event.target.checked)} /> I also list other brands</label>
        {mixed && <label className={styles.band}>TOTAL ACTIVE LISTED SKUs<select value={band} onChange={event => setBand(event.target.value)}><option value="0">1–100 SKUs</option><option value="1">101–500 SKUs</option><option value="2">501–1,000 SKUs</option><option value="custom">More than 1,000 SKUs</option></select></label>}
        <div aria-live="polite"><p className={styles.estimate}>{custom ? "LET’S REVIEW YOUR CATALOG" : `$${mfrPrice} / month`}</p><p className={styles.small}>{custom ? "We’ll discuss your catalog and pricing together." : `${mixed ? `($49 + $${tiers[Number(band)].price}) ÷ 2. ` : "Own-brand catalog. "}First 60 days free.`}</p></div>
        <a className={styles.button} href="#start-onboarding" onClick={() => setSelected(mfrLabel)}>{custom ? "REQUEST CATALOG REVIEW" : "CONTINUE WITH MFR"} <span aria-hidden="true">→</span></a>
      </div>
    </section>
    <section id="start-onboarding" className={`${styles.section} ${styles.onboarding}`} aria-labelledby="onboarding-title">
      <div><p className={styles.eyebrow}>LET’S GET ACQUAINTED.</p><h2 id="onboarding-title">YOUR NEXT STEP.</h2><p>Choose a plan above, then introduce your store. Participation and product listings require review before going live.</p><Link className={styles.textLink} href="/for-retailers">HOW GETTING LISTED WORKS ↗</Link></div>
      <div>{selected ? <><div className={styles.selection}><strong>YOUR SELECTION</strong><p>{selected}</p></div><InterestForm key={selected} selectedPlan={selected} /></> : <p className={styles.selection}>Select a plan to begin your introduction.</p>}</div>
    </section>
  </>;
}
