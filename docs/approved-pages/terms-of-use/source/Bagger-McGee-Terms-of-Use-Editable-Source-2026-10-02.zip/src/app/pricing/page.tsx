import { PublicHeader, PublicFooter } from "../public-shell";
import shared from "../home.module.css";
import styles from "./pricing.module.css";
import PlanSelection from "./plan-selection";

export default function PricingPage() {
  return <div className={shared.site}>
    <a className={shared.skip} href="#pricing-main">Skip to pricing</a>
    <PublicHeader />
    <main id="pricing-main" className={styles.main}>
      <div className={styles.hero}>
        <p className={styles.eyebrow}>YOUR CATALOG. YOUR PLAN.</p>
        <h1>RETAILER PRICING</h1>
        <p className={styles.intro}>Choose a plan for your complete Harley-Davidson and Indian parts catalog.<br />Your checkout. Your customers. Your business.</p>
        <div className={styles.trial}><strong>FIRST 60 DAYS FREE</strong><span>Explore your plan below. Monthly prices apply after your free period.</span></div>
      </div>
      <PlanSelection />
    </main>
    <PublicFooter previewNote="For Sam and Kenny. Pricing design preview. Plan selection and onboarding are demonstrations; no inquiries are sent or saved, no subscriptions are created, and no payments are collected. Live billing, trial activation, phone support, and catalog connections remain launch work. Remove design disclosures before launch." />
  </div>;
}
