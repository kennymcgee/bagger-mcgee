const grades = ["A", "B", "C", "D", "E"];

export function shippingFilterLabel(value: string): string {
  if (value === "Any score") return "Any score";
  if (value === "?") return "Unknown only";
  return value === "A" ? "A only" : `${value} or better`;
}

export function matchesShippingScore(score: string, selection: string): boolean {
  if (selection === "Any score") return true;
  if (selection === "?") return score === "?";
  const scoreRank = grades.indexOf(score);
  const threshold = grades.indexOf(selection);
  return scoreRank >= 0 && threshold >= 0 && scoreRank <= threshold;
}
