import Link from "next/link";
import { notFound } from "next/navigation";
import { findDemoOffer } from "../../demo-catalog";
import { PublicHeader, PublicFooter } from "../../public-shell";
import { ShareControl, CouponControl, FlagControl } from "../../listing-controls";
import styles from "../../home.module.css";
export default async function SharedListing({params,searchParams}:{params:Promise<{id:string}>;searchParams:Promise<{bike?:string}>}) {
 const {id}=await params;const offer=findDemoOffer(id);if(!offer)notFound();const query=await searchParams;const bike=typeof query.bike === "string" ? query.bike.slice(0,100) : "";
 return <div className={styles.site}><PublicHeader/><main className={styles.info}><Link href="/">← Browse all parts</Link><p className={styles.overline}>SHARED DEMO LISTING</p><h1>{offer.name}</h1><p>{offer.variant}</p><div className={styles.sharedCard}><h2>{offer.retailer}</h2><p>Part number: <strong>{offer.code}</strong><br/>Condition: {offer.condition}<br/>Shipping score: {offer.shippingScore} (fictional)</p><p className={styles.sharedPrice}>${offer.price.toFixed(2)}</p>{bike && <p>Shared bike context: {bike}. Fitment is simulated, not verified.</p>}<p>Real retailer name, fictional offer. No partnership is implied. Price excludes shipping and tax. This preview does not support purchases.</p><div className={styles.shareActions}><ShareControl id={id} name={offer.name} retailer={offer.retailer} bike={bike}/><CouponControl code={offer.coupon}/><FlagControl id={id} name={offer.name}/></div></div></main><PublicFooter/></div>;
}
