export const parts = [
  { name: "Touring comfort seat", category: "Seats", code: "DEMO-TCS", variant: "Black · diamond stitch · two-up", prices: [349, 369, 359] },
  { name: "Touring windscreen", category: "Windshields", code: "DEMO-TWS", variant: "Light smoke · 10-inch", prices: [149, 159, 154] },
  { name: "Touring slip-on exhaust", category: "Exhaust", code: "DEMO-TSE", variant: "Satin black · 4-inch · pair", prices: [499, 529, 519] },
];
export const stores = ["West End Motorsports", "Get Lowered Cycles", "Deadbeat Customs"];

export const demoOffers = parts.flatMap((part, demoPopularityRank) => stores.map((retailer, i) => ({ ...part, demoPopularityRank, retailer, shippingScore: ["A", "B", "C"][i], coupon: ["DEMO10", "DEMO15", "DEMO20"][i], price: part.prices[i], condition: "New Aftermarket", key: `${part.code}-${i}` })));
export function findDemoOffer(id: string) { return demoOffers.find(offer=>offer.key===id); }
