import { PublicHeader, PublicFooter } from "../public-shell";
import shared from "../home.module.css";
import styles from "./contact.module.css";
import ContactForm from "./contact-form";

export default function ContactPage() {
  return <div className={shared.site}>
    <a className={shared.skip} href="#contact-main">Skip to contact form</a><PublicHeader />
    <main id="contact-main" className={styles.main}>
      <div className={styles.hero}><h1>CONTACT US.<br /><span>WE’D LIKE TO HEAR FROM YOU.</span></h1><p>Got a question, an idea, or something we should know?<br />Drop us a line.</p></div>
      <div className={styles.layout}>
        <section className={styles.intro}><h2>WHAT’S ON YOUR MIND?</h2><p>Whether you’re finding parts for your ride or looking to list your retail catalog, start the conversation here.</p>
          
          <div className={styles.note}><h3>ASKING ABOUT A LISTING?</h3><p>Include the retailer, part name or number, and a link so we can find what you’re looking at.</p></div>
          <div className={styles.note}><h3>NEED HELP WITH AN ORDER?</h3><p>Contact the retailer you purchased from for payment, delivery, returns, or order updates. Purchases happen on their website.</p></div>
        <div className={styles.email}><p className={styles.eyebrow}>OUR EMAIL</p><p>hello@baggermcgee.com</p></div></section>
        <ContactForm />
      </div>
    </main>
    <PublicFooter previewNote="For Sam and Kenny. Contact Us design preview. The form is a demonstration: messages are not transmitted or saved. Live message delivery and inquiry handling remain launch work. Remove design disclosures before launch." />
  </div>;
}



