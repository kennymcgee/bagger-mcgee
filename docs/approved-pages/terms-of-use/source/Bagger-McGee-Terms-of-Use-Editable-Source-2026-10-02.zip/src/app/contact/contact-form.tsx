"use client";
import { useState } from "react";
import styles from "./contact.module.css";

export default function ContactForm() {
  const [message, setMessage] = useState("");
  return <div className={styles.card}><form className={styles.form} onSubmit={event => {event.preventDefault(); setMessage("Contact form preview only. Your message has not been sent or saved.");}} onChange={() => setMessage("")}>
    <p className={styles.eyebrow}>OVER TO YOU.</p><h2>SEND US A MESSAGE</h2>
    <label htmlFor="contact-name">YOUR NAME</label><input id="contact-name" name="name" autoComplete="name" required maxLength={120} />
    <label htmlFor="contact-email">EMAIL ADDRESS</label><input id="contact-email" name="email" type="email" autoComplete="email" required maxLength={254} />
    <label htmlFor="contact-topic">WHAT’S IT ABOUT?</label><select id="contact-topic" name="topic" required defaultValue=""><option value="" disabled>Choose a topic</option><option>General question</option><option>Retailer participation</option><option>Listing or Shipping Score issue</option><option>Website feedback</option><option>Something else</option></select>
    <label htmlFor="contact-message">YOUR MESSAGE</label><textarea id="contact-message" name="message" rows={6} required maxLength={5000} placeholder="Tell us how we can help." />
    <button className={styles.button} type="submit">SEND MESSAGE <span aria-hidden="true">→</span></button>
    <p className={styles.status} role="status">{message}</p>
  </form></div>;
}
