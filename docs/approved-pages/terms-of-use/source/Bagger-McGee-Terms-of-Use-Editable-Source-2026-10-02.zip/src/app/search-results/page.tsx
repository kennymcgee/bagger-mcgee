import PartsSearch from "../parts-search";

export default async function SearchResults({ searchParams }: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const make = params.make === "Indian" ? "Indian" : "Harley-Davidson";
  const models = make === "Indian" ? ["Challenger", "Chieftain"] : ["Road Glide", "Street Glide"];
  const year = typeof params.year === "string" && ["2023", "2022", "2021"].includes(params.year) ? params.year : "2023";
  const model = typeof params.model === "string" && models.includes(params.model) ? params.model : models[0];
  const selectedBike = params.make ? { make, year, model } : null;
  return <PartsSearch key={[make,year,model].join("-")} resultsPage selectedBike={selectedBike}/>;
}
