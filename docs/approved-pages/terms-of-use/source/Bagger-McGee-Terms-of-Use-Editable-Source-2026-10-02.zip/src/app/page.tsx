import PartsSearch from "./parts-search";

export default function Home() {
  return <PartsSearch/>;
}
