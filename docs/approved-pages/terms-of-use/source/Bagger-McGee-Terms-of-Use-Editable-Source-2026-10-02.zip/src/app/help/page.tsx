import Link from "next/link";
import type { ReactNode } from "react";
import { PublicHeader, PublicFooter } from "../public-shell";
import shared from "../home.module.css";
import styles from "./faq.module.css";

type Question = { question: string; answer: ReactNode };
const riderQuestions: Question[] = [
  { question: "What is Bagger McGee?", answer: <>A parts search and comparison site for Harley-Davidson and Indian riders. Find offers from retailers, compare the details, and choose where to buy. Bagger McGee is independent of both motorcycle brands.</> },
  { question: "Do I buy my parts from Bagger McGee?", answer: <>Your purchase happens with the retailer. The retailer handles checkout, payment, fulfillment, returns, and order support. Bagger McGee helps you compare offers and find your next part.</> },
  { question: "How do I find parts for my bike?", answer: <>Choose your make, year, and model, then select FIND PARTS. Narrow the results by category, retailer, condition, item price, or shipping score. You can also browse before selecting a bike. For a walkthrough, see the <Link href="/quick-tutorial">Quick Tutorial</Link>.</> },
  { question: "Does selecting my bike guarantee a part will fit?", answer: <>Always confirm the exact application with the retailer before buying. Check the manufacturer part number, model year, variant, and any installation requirements. Modifications to your bike can affect fitment.</> },
  { question: "What do NEW, USED, OEM, and AFTERMARKET mean?", answer: <>NEW and USED describe the offer’s condition. OEM identifies original-equipment parts; AFTERMARKET identifies parts from other manufacturers. Compare the exact part and variant as well as its condition, and check the retailer’s description for what is included.</> },
  { question: "Is the price shown the total I will pay?", answer: <>The listed price is the item price. Shipping, handling, and tax can change the total. Confirm the final amount at the retailer’s checkout, including any coupon restrictions, before placing your order.</> },
  { question: "What does the Shipping Score tell me?", answer: <>It is a guide to shipping and handling costs: A is lowest, E is highest, and ? means there is not enough verified information to assign a score. It is not a delivery-speed or customer-service rating, and it is not a shipping quote. FREE means no conditions or minimum; COND means conditions apply. See <Link href="/shipping-score">Shipping Score</Link> for the full explanation.</> },
  { question: "How do I compare and sort offers?", answer: <>Check the brand, manufacturer part number, and variant so you are comparing the same part. Use the CONDITION, PRICE, or SHIP SCORE headings to change the order. Consider the whole offer—item price, shipping, condition, and retailer terms—before deciding.</> },
  { question: "How do coupons, sharing, and reporting work?", answer: <>Use the copy icon beside a coupon, then check its terms and apply it at the retailer’s checkout. Use the share arrow to copy a listing link. If a listing looks wrong, the skull-and-crossbones flag opens the listing-issue form. An issue report is separate from an order-support request.</> },
  { question: "Who do I contact about an order, return, or warranty?", answer: <>Start with the retailer you purchased from. Keep your order confirmation and check that retailer’s shipping, return, and warranty terms. Bagger McGee does not process purchases or manage retailer orders.</> },
];
const retailerQuestions: Question[] = [
  { question: "Who is Get Listed for?", answer: <>Retailers carrying parts for Harley-Davidson or Indian motorcycles. Start with an introduction to your store and the parts you carry. Participation and product listings are reviewed before approval. Visit <Link href="/for-retailers">Get Listed</Link> to see the process.</> },
  { question: "Where does the sale happen?", answer: <>On <em>your</em> website. Riders compare offers on Bagger McGee and follow the product link to your website. You keep your checkout, fulfillment, and customer relationship, including returns and order support.</> },
  { question: "How does onboarding work?", answer: <>Introduce your store, work through participation and catalog details with us, then review the listings before going live. We discuss permission to use your product data and how it will be supplied and kept current. An introduction does not automatically publish your catalog.</> },
  { question: "What catalog information will you need?", answer: <>Brand, manufacturer part number, and variant; supported fitment information; current price, condition, availability, and product link; plus shipping charges, free-shipping thresholds, and restrictions. Exact details help riders compare the same part across offers.</> },
  { question: "Do I need to have a product feed ready?", answer: <>Start with an introduction. We will work through how your catalog can be supplied, reviewed, and updated together. The data connection and permission to use it are part of onboarding.</> },
  { question: "What does participation cost?", answer: <>Commercial terms are still being finalized. Participation details will be discussed during onboarding so you can review them before deciding to join.</> },
  { question: "Can I speak with a real person during onboarding?", answer: <>Yes. At any stage of onboarding, you can call and speak with a live human agent, not AI. From a quick question to help with catalog details, a real person will walk you through the process.</> },
  { question: "How are Shipping Scores reviewed?", answer: <>The score reflects shipping and handling costs, including fees, minimums, and free-shipping restrictions. Regular reviews and reassessment when policies change are planned. For a review request, provide the retailer, part, and quoted shipping charge. Review timing is still being finalized. See <Link href="/shipping-score">Shipping Score</Link> for the method.</> },
];

function Questions({ items, openFirst = false }: { items: Question[]; openFirst?: boolean }) {
  return <div className={styles.questions}>{items.map(({ question, answer }, index) =>
    <details key={question} name="bagger-faq" open={openFirst && index === 0}>
      <summary>{question}<span className={styles.toggle} aria-hidden="true" /></summary>
      <p>{answer}</p>
    </details>
  )}</div>;
}

export default function Help() {
  return <div className={shared.site}>
    <a className={shared.skip} href="#faq-main">Skip to frequently asked questions</a>
    <PublicHeader />
    <main id="faq-main" className={styles.main}>
      <div className={styles.hero}>
        <p className={styles.eyebrow}>GOOD QUESTIONS. STRAIGHT ANSWERS.</p>
        <h1>FAQ</h1>
        <p className={styles.intro}>Finding your next part. Getting your store listed.<br />Here’s what you need to know.</p>
        <nav className={styles.jumpLinks} aria-label="FAQ sections"><a href="#riders">FOR RIDERS <span aria-hidden="true">↓</span></a><a href="#retailers">FOR RETAILERS <span aria-hidden="true">↓</span></a></nav>
      </div>
      <section id="riders" className={styles.section} aria-labelledby="riders-title">
        <div className={styles.sectionHeading}><p className={styles.eyebrow}>YOUR BIKE. YOUR NEXT PART.</p><h2 id="riders-title">FOR RIDERS</h2><p>Find it. Compare it.<br />Know what you’re buying.</p><Link href="/quick-tutorial">QUICK TUTORIAL <span aria-hidden="true">↗</span></Link></div>
        <Questions items={riderQuestions} openFirst />
      </section>
      <section id="retailers" className={styles.section} aria-labelledby="retailers-title">
        <div className={styles.sectionHeading}><p className={styles.eyebrow}>YOUR PARTS. THEIR NEXT RIDE.</p><h2 id="retailers-title">FOR RETAILERS</h2><p>Get discovered.<br />Keep the customer.</p><Link href="/for-retailers">GET LISTED <span aria-hidden="true">↗</span></Link></div>
        <Questions items={retailerQuestions} />
      </section>
    </main>
    <PublicFooter previewNote="For Sam and Kenny. FAQ design concept. Catalog, fitment, popularity order, prices, coupons, and shipping scores remain illustrative; retailer participation is not established. Retailer actions open demo panels, share links are local preview links, and listing reports save in this browser only. The Get Listed form sends and saves nothing. Commercial terms, live referrals, phone support, and contact services remain launch work. Remove design disclosures before launch." />
  </div>;
}


