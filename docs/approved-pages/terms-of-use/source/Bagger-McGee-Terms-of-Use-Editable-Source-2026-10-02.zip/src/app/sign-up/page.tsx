import { PublicHeader, PublicFooter } from "../public-shell";
import shared from "../home.module.css";
import styles from "./signup.module.css";
import SignupExperience from "./signup-experience";
export default function SignupPage() {
  return <div className={shared.site}>
    <a className={shared.skip} href="#signup-main">Skip to sign up</a><PublicHeader />
    <main id="signup-main" className={styles.main}>
      <div className={styles.hero}><p className={styles.eyebrow}>YOUR BIKES. YOUR PARTS. YOUR GARAGE.</p><h1>SIGN UP.<br /><span>BUILD YOUR GARAGE.</span></h1><p>One bike or a whole lineup. Keep your Harley-Davidson and Indian bikes together and make every parts search start with your ride.</p></div>
      <SignupExperience />
      <section className={styles.section}><p className={styles.eyebrow}>MORE REASONS TO JOIN</p><h2>LESS REPEATING. MORE RIDING.</h2><div className={styles.benefits}>
        <article><span>01 / YOUR GARAGE</span><h3>ADD ALL YOUR BIKES</h3><p>Keep the make, year, and model of each bike ready to go. Give each ride a nickname so it’s easy to find.</p></article>
        <article><span>02 / SMARTER SEARCH</span><h3>CHECK YOUR RIDE. FIND YOUR PARTS.</h3><p>Select one or several bikes with a checkbox. See matching parts grouped by bike so you know which ride each part fits. Confirm fitment with the retailer before buying.</p></article>
        <article><span>03 / RIDER FEEDBACK</span><h3>RATE YOUR RETAILER</h3><p>Share your experience and a one-to-five-star rating. Every review goes to Bagger McGee for approval before it appears publicly.</p></article>
        <article><span>04 / SAVED PARTS</span><h3>KEEP A BUILD LIST</h3><p>Save parts you’re considering and organize them by bike. Pick up your next project where you left off.</p></article>
        <article><span>05 / SAVED SEARCHES</span><h3>SKIP THE SAME SETUP</h3><p>Keep your favorite searches and filters handy for the next time you need parts.</p></article>
        <article><span>06 / RECENT COMPARISONS</span><h3>COME BACK TO YOUR SHORTLIST</h3><p>Return to parts and retailers you’ve compared without starting from scratch.</p></article>
      </div></section>
      <section className={styles.reviewNote}><h2>REAL EXPERIENCES. REVIEWED FIRST.</h2><p>Retailer reviews should cover a purchase or direct experience: shipping, communication, service, and whether the order matched the listing. Your review and star rating are sent to <strong>hello@baggermcgee.com</strong> for review before publication.</p><p>Rider ratings are separate from the Shipping Score. Leave out order numbers, addresses, and other private details.</p></section>
    </main>
    <PublicFooter previewNote="For Sam and Kenny. Rider account design preview: no account is created, no password is collected, and Garage entries exist only until this page is refreshed. Bike-fit filtering, saved parts, saved searches, and recent comparisons are proposed account features. The review action opens an email draft addressed to hello@baggermcgee.com; it does not send automatically, save a review, or publish a rating. Secure rider authentication, persistent Garage storage, verified multi-bike fitment, and an email-backed approval queue remain launch work. Remove design disclosures before launch." />
  </div>;
}
