"use client";
import { useState } from "react";
import styles from "./signup.module.css";
type Bike = { id: number; make: string; year: string; model: string; nickname: string; checked: boolean };
export default function SignupExperience() {
  const [ready, setReady] = useState(false);
  const [bikes, setBikes] = useState<Bike[]>([]);
  const [rating, setRating] = useState("5");
  const [status, setStatus] = useState("");
  const [reviewStatus, setReviewStatus] = useState("");
  return <>
    <div className={styles.join}>
      <div><p className={styles.eyebrow}>MADE FOR HARLEY + INDIAN RIDERS</p><h2>A HOME FOR<br />YOUR NEXT BUILD.</h2><p>Add your bikes once. Choose your ride when you search. Keep the parts you want close and help other riders find retailers they can trust.</p><a href="#garage-preview" className={styles.textLink}>TAKE A LOOK INSIDE THE GARAGE →</a></div>
      <form className={styles.form} onSubmit={event => { event.preventDefault(); setReady(true); setStatus("Sign-up preview complete. Explore your Garage below. No account has been created."); }}>
        <h2>CREATE YOUR ACCOUNT</h2><label>YOUR NAME<input name="name" autoComplete="name" required maxLength={100} /></label><label>EMAIL ADDRESS<input name="email" type="email" autoComplete="email" required maxLength={254} /></label><label>PUBLIC RIDER NAME<input name="handle" autoComplete="nickname" required minLength={3} maxLength={40} /><small>This is the name other riders will see on your reviews.</small></label>
        <button className={styles.button} type="submit">CREATE ACCOUNT <span aria-hidden="true">→</span></button><p role="status" className={styles.status}>{status}</p>
      </form>
    </div>
    <section id="garage-preview" className={styles.section}><p className={styles.eyebrow}>YOUR GARAGE</p><h2>{ready ? "LET’S ADD YOUR FIRST RIDE." : "ONE GARAGE. EVERY RIDE."}</h2><p className={styles.intro}>Add a bike, then check the rides you want to search for.</p>
      <form className={styles.bikeForm} onSubmit={event => { event.preventDefault(); const data = new FormData(event.currentTarget); setBikes(current => [...current, { id: Date.now(), make: String(data.get("make")), year: String(data.get("year")), model: String(data.get("model")).trim(), nickname: String(data.get("nickname")).trim(), checked: true }]); event.currentTarget.reset(); }}>
        <label>MAKE<select name="make"><option>Harley-Davidson</option><option>Indian</option></select></label><label>YEAR<input name="year" type="number" min={1901} max={new Date().getFullYear()+1} placeholder="2023" required /></label><label>MODEL<input name="model" placeholder="Road Glide" required maxLength={80} pattern=".*\S.*" /></label><label>NICKNAME <small>(OPTIONAL)</small><input name="nickname" placeholder="My weekend ride" maxLength={60} /></label><button className={styles.button}>ADD BIKE +</button>
      </form>
      <div className={styles.garageList}>{bikes.length === 0 ? <p className={styles.empty}>Your bikes belong here. Add your first ride above.</p> : bikes.map(bike => <div className={styles.bike} key={bike.id}><label><input type="checkbox" checked={bike.checked} onChange={() => setBikes(current => current.map(item => item.id === bike.id ? {...item, checked: !item.checked} : item))} /><span><strong>{bike.nickname || bike.model}</strong><small>{bike.year} {bike.make} {bike.model}</small></span></label><button type="button" aria-label={`Remove ${bike.nickname || bike.model}`} onClick={() => setBikes(current => current.filter(item => item.id !== bike.id))}>REMOVE</button></div>)}</div>
      {bikes.length > 0 && <p className={styles.selection} role="status">{bikes.filter(bike => bike.checked).length} {bikes.filter(bike => bike.checked).length === 1 ? "bike" : "bikes"} selected · {bikes.filter(bike => bike.checked).map(bike => `${bike.year} ${bike.make} ${bike.model}`).join(" / ") || "Check a bike to include it in your search."}</p>}
    </section>
    <section className={styles.section}><p className={styles.eyebrow}>HAVE A RETAILER EXPERIENCE TO SHARE?</p><h2>YOUR RATING. YOUR WORDS.</h2><form className={styles.form} onSubmit={event => { event.preventDefault(); const data = new FormData(event.currentTarget); const body = `Retailer review for approval\n\nRetailer: ${data.get("retailer")}\nWebsite: ${data.get("website") || "Not provided"}\nRider name: ${data.get("rider")}\nRating: ${rating}/5 stars\n\nExperience:\n${data.get("review")}\n\nPlease review before posting publicly.`; window.location.href = `mailto:hello@baggermcgee.com?subject=${encodeURIComponent("Retailer review for approval")}&body=${encodeURIComponent(body)}`; setReviewStatus("Email draft requested. Send it from your email app to request approval; nothing is posted here."); }}>
      <div className={styles.reviewFields}><label>RETAILER NAME<input name="retailer" required maxLength={150} /></label><label>RETAILER WEBSITE <small>(OPTIONAL)</small><input name="website" type="url" placeholder="https://" maxLength={300} /></label><label>YOUR PUBLIC RIDER NAME<input name="rider" required maxLength={40} /></label></div>
      <fieldset className={styles.stars}><legend>YOUR STAR RATING</legend>{[1,2,3,4,5].map(value => <label key={value}><input type="radio" name="rating" value={value} checked={rating === String(value)} onChange={event => setRating(event.target.value)} /><span aria-hidden="true" className={value <= Number(rating) ? styles.lit : ""}>★</span><span>{value} {value === 1 ? "star" : "stars"}</span></label>)}</fieldset>
      <label>YOUR EXPERIENCE<textarea name="review" rows={4} required minLength={20} maxLength={3000} placeholder="Tell other riders about your experience with this retailer." /></label><button className={styles.button}>EMAIL REVIEW FOR APPROVAL →</button><p role="status" className={styles.status}>{reviewStatus}</p><p className={styles.intro}>Opens your email app. Reviews appear publicly only after approval.</p>
    </form></section>
  </>;
}

