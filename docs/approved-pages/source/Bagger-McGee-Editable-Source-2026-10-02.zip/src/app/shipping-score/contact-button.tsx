"use client";

import { useRef } from "react";
import shared from "../home.module.css";
import styles from "./shipping.module.css";

export default function ContactButton() {
  const dialog = useRef<HTMLDialogElement>(null);
  return <>
    <button type="button" className={styles.contactButton} onClick={() => dialog.current?.showModal()}>CONTACT US</button>
    <dialog ref={dialog} className={shared.shareDialog} aria-labelledby="shipping-contact-title">
      <div className={shared.dialogHeading}><span>BAGGER McGEE</span><button type="button" aria-label="Close contact" onClick={() => dialog.current?.close()}>×</button></div>
      <h2 id="shipping-contact-title">CONTACT US</h2>
      <p>Contact details will be available when the site launches. To request a shipping score review, include the retailer, the part, and the shipping charge you were quoted.</p>
      <button type="button" className={shared.primary} onClick={() => dialog.current?.close()}>Close</button>
    </dialog>
  </>;
}
