<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

## Bagger McGee design continuity
Use PublicHeader and PublicFooter from src/app/public-shell.tsx on every public page. Sign Up is the approved reference for the shared shell. Keep layout, typography, spacing, colors, navigation labels and destinations consistent; page-specific private preview notes belong at the bottom. When Kenny changes a shared design, apply it through shared components to all pages. Speak up about inconsistencies in design, flow or content before silently changing approved page bodies. Preserve original PDFs and add dated revisions and index entries. Never treat an archived approval as implemented live functionality.

