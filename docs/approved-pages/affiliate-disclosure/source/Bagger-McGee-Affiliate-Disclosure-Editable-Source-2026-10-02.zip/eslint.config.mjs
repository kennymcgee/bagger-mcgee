import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

export default defineConfig([
  ...nextVitals,
  ...nextTs,
  globalIgnores([".next/**", ".next-review/**", ".next-decisions/**", ".next-corrections/**", ".next-approvals/**", ".next-database-review/**", ".next-upload/**", "out/**", "next-env.d.ts"]),
]);





